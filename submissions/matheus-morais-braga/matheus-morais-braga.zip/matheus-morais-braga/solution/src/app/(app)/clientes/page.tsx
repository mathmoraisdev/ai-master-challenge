import { ClientesView } from "@/components/clientes/ClientesView";

export const dynamic = "force-dynamic";

export default function ClientesPage() {
  return <ClientesView />;
}
