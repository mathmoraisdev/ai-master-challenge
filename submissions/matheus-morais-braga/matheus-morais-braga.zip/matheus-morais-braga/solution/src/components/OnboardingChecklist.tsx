"use client";

import Link from "next/link";
import {
  Check,
  Store,
  MessageSquare,
  Upload,
  Megaphone,
  Bot,
  CalendarClock,
  Package,
  Boxes,
  Users2,
  ArrowRight,
  ShoppingBag,
  Bike,
  Globe,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { HelpHint } from "@/components/ui/HelpHint";
import { cn } from "@/lib/utils";
import type {
  OnboardingState,
  OnboardingStepKey,
  CatalogVariant,
} from "@/server/services/onboarding.service";

/** Copy do passo de catálogo por variante de ramo. */
const CATALOG_COPY: Record<CatalogVariant, { title: string; description: string }> = {
  produtos: {
    title: "Cadastre seus produtos",
    description: "Adicione itens com preço (e custo, p/ ver sua margem no caixa).",
  },
  servicos: {
    title: "Cadastre seus serviços",
    description: "Adicione os serviços com preço e duração — a agenda usa a duração.",
  },
  ambos: {
    title: "Cadastre produtos e serviços",
    description: "Monte seu catálogo: serviços (com duração) e produtos (com preço/custo).",
  },
};

/**
 * Apresentação (ícone/título/descrição/CTA) por passo, indexada pela `key`. A
 * ordem de render segue `state.steps`, que já vem filtrado e ordenado pelo
 * service conforme o plano do dono.
 */
const STEP_META: Record<
  OnboardingStepKey,
  { icon: LucideIcon; title: string; description: string; href: string; cta: string; help: string }
> = {
  ramo: {
    icon: Store,
    title: "Escolha o seu ramo de negócio",
    description: "1 clique configura tema, campos, catálogo, funil e a persona da IA de uma vez.",
    href: "/configuracoes#configuracao-rapida-ramo",
    cta: "Escolher ramo",
    help: "O ramo molda o app inteiro: quais campos aparecem na comanda, o que a IA sabe responder e quais módulos ficam em destaque. Dá pra trocar depois — nada fica travado.",
  },
  number: {
    icon: MessageSquare,
    title: "Conecte um número de WhatsApp",
    description: "Pareie um chip para começar a enviar e receber mensagens.",
    href: "/empresas",
    cta: "Conectar número",
    help: "Sem um número conectado, o Atendimento e as Campanhas não têm por onde enviar mensagem. É o pré-requisito de quase tudo.",
  },
  leads: {
    icon: Upload,
    title: "Importe seus leads",
    description: "Suba um CSV de contatos pelo botão “Importar CSV” aqui em cima.",
    href: "/leads",
    cta: "Importar CSV",
    help: "Aceita um CSV com nome e telefone. Contatos repetidos são ignorados — pode subir a lista inteira sem medo de duplicar.",
  },
  ai: {
    icon: Bot,
    title: "Configure a IA de atendimento",
    description: "Conecte sua chave para a IA qualificar leads automaticamente.",
    href: "/configuracoes",
    cta: "Configurar IA",
    help: "A IA usa a persona e a base de conhecimento do seu ramo para responder no seu tom. Você revisa o texto antes de ligar.",
  },
  catalogo: {
    icon: Package,
    // título/descrição resolvidos por variante em tempo de render (ver CATALOG_COPY)
    title: "Monte seu catálogo",
    description: "Cadastre o que você vende.",
    href: "/catalogo",
    cta: "Abrir catálogo",
    help: "O catálogo alimenta o caixa, a agenda e a IA de atendimento. Serviços têm duração; produtos podem ter controle de estoque.",
  },
  estoque: {
    icon: Boxes,
    title: "Ligue o controle de estoque",
    description: "Ative o estoque nos produtos e informe as quantidades iniciais.",
    href: "/estoque",
    cta: "Configurar estoque",
    help: "O estoque baixa sozinho no fechamento da comanda e avisa quando um produto está acabando. Opt-in por produto — só liga no que você quer controlar.",
  },
  menu_catalog: {
    icon: ShoppingBag,
    title: "Monte seu cardápio online",
    description: "Marque os itens como visíveis no cardápio e organize por categoria.",
    href: "/catalogo",
    cta: "Montar cardápio",
    help: "Itens com “visível no cardápio” ligado aparecem na página pública /cardapio/<slug>. Defina a categoria (ex.: Lanches, Bebidas) para agrupar na vitrine.",
  },
  delivery_config: {
    icon: Bike,
    title: "Configure entrega e taxas",
    description: "Defina bairros, taxas de entrega, pedido mínimo e modalidades.",
    href: "/configuracoes/delivery",
    cta: "Configurar entrega",
    help: "Crie zonas de bairro com taxa e pedido mínimo próprios. Aqui também liga/desliga entrega, retirada e pagamento online (Pix) ou na entrega.",
  },
  menu_publish: {
    icon: Globe,
    title: "Publique seu cardápio",
    description: "Ligue o cardápio online e copie o link público para divulgar.",
    href: "/configuracoes/delivery",
    cta: "Publicar cardápio",
    help: "Ao publicar, o link /cardapio/<slug> fica ativo — clientes pedem sem login, com carrinho e checkout. Desligar a qualquer momento esconde a página (404).",
  },
  agenda_setup: {
    icon: Users2,
    title: "Configure sua agenda",
    description: "Cadastre profissionais/recursos e seus horários de atendimento.",
    href: "/agenda",
    cta: "Configurar agenda",
    help: "Com profissionais e expediente definidos, a Agenda evita conflitos de horário e o link público de agendamento passa a funcionar.",
  },
  campaign: {
    icon: Megaphone,
    title: "Crie e dispare uma campanha",
    description: "Monte a mensagem com {{nome}} e comece a falar com o funil.",
    href: "/campaigns",
    cta: "Criar campanha",
    help: "Use {{nome}} para personalizar. O disparo respeita o número conectado e o ritmo de envio para proteger o chip.",
  },
  meeting: {
    icon: CalendarClock,
    title: "Agende sua primeira reunião",
    description: "Marque um agendamento na Agenda — o lead recebe lembrete no WhatsApp.",
    href: "/agenda",
    cta: "Abrir agenda",
    help: "O lembrete sai automático pelo WhatsApp na véspera e perto da hora, reduzindo faltas. Só aparece para ramos que trabalham com hora marcada.",
  },
};

/**
 * Checklist de primeiros passos, ciente do plano. Renderiza só os passos
 * aplicáveis (`state.steps`, vindos do service) e marca cada um como check verde
 * quando concluído. O card some por completo quando `state.done` — não polui a
 * tela de quem já configurou tudo.
 */
export function OnboardingChecklist({ state }: { state: OnboardingState }) {
  if (state.done) return null;

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
        <div>
          <h3 className="text-sm font-bold text-ink">Primeiros passos</h3>
          <p className="mt-0.5 text-xs text-slate-500">
            Configure sua conta para começar a vender no WhatsApp.
          </p>
        </div>
        <span className="text-xs font-bold text-slate-500">
          {state.completed} de {state.total}
        </span>
      </div>

      <ol className="divide-y divide-slate-100">
        {state.steps.map((step) => {
          const meta = STEP_META[step.key];
          const Icon = meta.icon;
          const copy =
            step.key === "catalogo" && step.variant
              ? CATALOG_COPY[step.variant]
              : { title: meta.title, description: meta.description };
          return (
            <li
              key={step.key}
              className="flex items-center gap-4 px-5 py-4"
            >
              <span
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                  step.done
                    ? "bg-brand-500 text-white"
                    : "bg-[#EBF0ED] text-slate-500",
                )}
              >
                {step.done ? <Check size={18} /> : <Icon size={17} />}
              </span>

              <div className="min-w-0 flex-1">
                <p
                  className={cn(
                    "flex items-center gap-1.5 text-sm font-bold",
                    step.done ? "text-slate-400 line-through" : "text-ink",
                  )}
                >
                  {copy.title}
                  {!step.done && <HelpHint label={`Sobre: ${copy.title}`}>{meta.help}</HelpHint>}
                </p>
                <p className="mt-0.5 text-xs text-slate-500">{copy.description}</p>
              </div>

              {!step.done && (
                <Link
                  href={meta.href}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-brand-500 px-3 py-1.5 text-xs font-semibold text-white shadow-[0_8px_20px_-8px_rgba(14,164,107,.55)] transition-colors hover:bg-brand-600"
                >
                  {meta.cta} <ArrowRight size={14} />
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </Card>
  );
}
